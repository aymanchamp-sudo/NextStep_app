import React from "react";
import { StyleSheet, Text, View, Pressable, Platform, ActivityIndicator } from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import Colors from "@/constants/colors";
import { useData } from "@/lib/data-context";

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const { goals, isLoading } = useData();
  const webTopInset = Platform.OS === "web" ? 67 : 0;

  const totalTasks = goals.reduce((sum, g) => sum + g.tasks.length, 0);
  const completedTasks = goals.reduce((sum, g) => sum + g.tasks.filter((t) => t.completed).length, 0);
  const pendingTasks = totalTasks - completedTasks;

  const handleAsk = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    if (pendingTasks === 0) return;
    router.push("/input-modal");
  };

  if (isLoading) {
    return (
      <View style={[styles.container, { paddingTop: insets.top + webTopInset }]}>
        <ActivityIndicator size="large" color={Colors.primary} />
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top + webTopInset }]}>
      <View style={styles.header}>
        <Text style={styles.greeting}>NextStep</Text>
        <Text style={styles.subtitle}>Focus on what matters most</Text>
      </View>

      <View style={styles.centerContent}>
        <Pressable
          onPress={handleAsk}
          style={({ pressed }) => [
            styles.mainButtonWrapper,
            { transform: [{ scale: pressed ? 0.96 : 1 }], opacity: pendingTasks === 0 ? 0.5 : 1 },
          ]}
          disabled={pendingTasks === 0}
        >
          <LinearGradient
            colors={[Colors.primary, Colors.primaryDark]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.mainButton}
          >
            <Ionicons name="compass" size={40} color="#fff" />
            <Text style={styles.mainButtonText}>What should I do now?</Text>
            <Text style={styles.mainButtonHint}>
              {pendingTasks > 0
                ? `${pendingTasks} task${pendingTasks !== 1 ? "s" : ""} waiting`
                : "Add tasks to get started"}
            </Text>
          </LinearGradient>
        </Pressable>
      </View>

      <View style={styles.statsRow}>
        <View style={styles.statCard}>
          <View style={[styles.statDot, { backgroundColor: Colors.primary }]} />
          <Text style={styles.statNumber}>{goals.length}</Text>
          <Text style={styles.statLabel}>Goals</Text>
        </View>
        <View style={styles.statCard}>
          <View style={[styles.statDot, { backgroundColor: Colors.accent }]} />
          <Text style={styles.statNumber}>{pendingTasks}</Text>
          <Text style={styles.statLabel}>Pending</Text>
        </View>
        <View style={styles.statCard}>
          <View style={[styles.statDot, { backgroundColor: Colors.success }]} />
          <Text style={styles.statNumber}>{completedTasks}</Text>
          <Text style={styles.statLabel}>Done</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingHorizontal: 24,
  },
  header: {
    paddingTop: 16,
    paddingBottom: 8,
  },
  greeting: {
    fontFamily: "Outfit_700Bold",
    fontSize: 32,
    color: Colors.text,
  },
  subtitle: {
    fontFamily: "Outfit_400Regular",
    fontSize: 16,
    color: Colors.textSecondary,
    marginTop: 4,
  },
  centerContent: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  mainButtonWrapper: {
    width: "100%",
    borderRadius: 24,
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
    elevation: 8,
  },
  mainButton: {
    borderRadius: 24,
    paddingVertical: 48,
    paddingHorizontal: 32,
    alignItems: "center",
    gap: 12,
  },
  mainButtonText: {
    fontFamily: "Outfit_600SemiBold",
    fontSize: 22,
    color: "#fff",
    textAlign: "center",
  },
  mainButtonHint: {
    fontFamily: "Outfit_400Regular",
    fontSize: 14,
    color: "rgba(255,255,255,0.7)",
  },
  statsRow: {
    flexDirection: "row",
    gap: 12,
    paddingBottom: Platform.OS === "web" ? 34 + 84 : 100,
  },
  statCard: {
    flex: 1,
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 16,
    alignItems: "center",
    gap: 4,
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  statDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginBottom: 4,
  },
  statNumber: {
    fontFamily: "Outfit_700Bold",
    fontSize: 24,
    color: Colors.text,
  },
  statLabel: {
    fontFamily: "Outfit_400Regular",
    fontSize: 12,
    color: Colors.textSecondary,
  },
});
