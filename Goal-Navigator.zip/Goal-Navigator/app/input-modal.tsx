import React, { useState } from "react";
import { StyleSheet, Text, View, Pressable, Platform } from "react-native";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";
import { EnergyLevel } from "@/lib/types";

const TIME_OPTIONS = [
  { label: "15 min", value: 15 },
  { label: "30 min", value: 30 },
  { label: "1 hour", value: 60 },
  { label: "2 hours", value: 120 },
  { label: "3+ hours", value: 180 },
];

const ENERGY_OPTIONS: { label: string; value: EnergyLevel; icon: string; color: string }[] = [
  { label: "Low", value: "low", icon: "battery-dead", color: Colors.energyLow },
  { label: "Medium", value: "medium", icon: "battery-half", color: Colors.energyMedium },
  { label: "High", value: "high", icon: "battery-full", color: Colors.energyHigh },
];

export default function InputModal() {
  const [time, setTime] = useState<number>(30);
  const [energy, setEnergy] = useState<EnergyLevel>("medium");

  const handleSubmit = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    router.replace({
      pathname: "/result",
      params: { time: time.toString(), energy },
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>How are you feeling?</Text>

      <View style={styles.section}>
        <Text style={styles.sectionLabel}>Available time</Text>
        <View style={styles.chipRow}>
          {TIME_OPTIONS.map((opt) => (
            <Pressable
              key={opt.value}
              onPress={() => {
                Haptics.selectionAsync();
                setTime(opt.value);
              }}
              style={[
                styles.chip,
                time === opt.value && styles.chipActive,
              ]}
            >
              <Text
                style={[
                  styles.chipText,
                  time === opt.value && styles.chipTextActive,
                ]}
              >
                {opt.label}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionLabel}>Energy level</Text>
        <View style={styles.energyRow}>
          {ENERGY_OPTIONS.map((opt) => (
            <Pressable
              key={opt.value}
              onPress={() => {
                Haptics.selectionAsync();
                setEnergy(opt.value);
              }}
              style={[
                styles.energyCard,
                energy === opt.value && { borderColor: opt.color, backgroundColor: opt.color + "15" },
              ]}
            >
              <Ionicons
                name={opt.icon as any}
                size={24}
                color={energy === opt.value ? opt.color : Colors.textTertiary}
              />
              <Text
                style={[
                  styles.energyLabel,
                  energy === opt.value && { color: opt.color },
                ]}
              >
                {opt.label}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      <Pressable
        onPress={handleSubmit}
        style={({ pressed }) => [
          styles.submitButton,
          { transform: [{ scale: pressed ? 0.97 : 1 }] },
        ]}
      >
        <Text style={styles.submitText}>Find my next step</Text>
        <Ionicons name="arrow-forward" size={20} color="#fff" />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingHorizontal: 24,
    paddingTop: 24,
    gap: 24,
  },
  title: {
    fontFamily: "Outfit_700Bold",
    fontSize: 24,
    color: Colors.text,
    textAlign: "center",
  },
  section: {
    gap: 10,
  },
  sectionLabel: {
    fontFamily: "Outfit_500Medium",
    fontSize: 14,
    color: Colors.textSecondary,
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  chipRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  chip: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: Colors.surfaceAlt,
    borderWidth: 1.5,
    borderColor: "transparent",
  },
  chipActive: {
    backgroundColor: Colors.primaryLight,
    borderColor: Colors.primary,
  },
  chipText: {
    fontFamily: "Outfit_500Medium",
    fontSize: 15,
    color: Colors.textSecondary,
  },
  chipTextActive: {
    color: Colors.primary,
  },
  energyRow: {
    flexDirection: "row",
    gap: 10,
  },
  energyCard: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 16,
    borderRadius: 16,
    backgroundColor: Colors.surfaceAlt,
    borderWidth: 1.5,
    borderColor: "transparent",
    gap: 6,
  },
  energyLabel: {
    fontFamily: "Outfit_500Medium",
    fontSize: 13,
    color: Colors.textTertiary,
  },
  submitButton: {
    backgroundColor: Colors.primary,
    borderRadius: 16,
    paddingVertical: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 4,
  },
  submitText: {
    fontFamily: "Outfit_600SemiBold",
    fontSize: 17,
    color: "#fff",
  },
});
