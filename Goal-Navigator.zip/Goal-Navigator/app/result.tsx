import React, { useMemo } from "react";
import { StyleSheet, Text, View, Pressable, Platform } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";
import { useData } from "@/lib/data-context";
import { recommend } from "@/lib/recommendation-engine";
import { EnergyLevel } from "@/lib/types";

const ENERGY_ICONS: Record<string, string> = {
  low: "battery-dead",
  medium: "battery-half",
  high: "battery-full",
};

const PRIORITY_COLORS: Record<string, string> = {
  low: Colors.textTertiary,
  medium: Colors.primary,
  high: Colors.warning,
  urgent: Colors.error,
};

export default function ResultScreen() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ time: string; energy: string }>();
  const { goals, completeTask } = useData();
  const webTopInset = Platform.OS === "web" ? 67 : 0;

  const result = useMemo(() => {
    const availableMinutes = parseInt(params.time || "30", 10);
    const energyLevel = (params.energy || "medium") as EnergyLevel;
    return recommend(goals, { availableMinutes, energyLevel });
  }, [goals, params.time, params.energy]);

  const handleComplete = async () => {
    if (!result) return;
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    await completeTask(result.goal.id, result.task.id);
    router.dismissAll();
  };

  const handleSkip = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.dismissAll();
  };

  if (!result) {
    return (
      <View style={[styles.container, { paddingTop: insets.top + webTopInset }]}>
        <Pressable
          onPress={() => router.dismissAll()}
          style={({ pressed }) => [styles.closeBtn, { opacity: pressed ? 0.6 : 1 }]}
        >
          <Ionicons name="close" size={24} color={Colors.text} />
        </Pressable>
        <View style={styles.emptyContainer}>
          <Ionicons name="search-outline" size={56} color={Colors.textTertiary} />
          <Text style={styles.emptyTitle}>No matching task</Text>
          <Text style={styles.emptyText}>
            No tasks fit your current time and energy. Try adjusting your inputs or adding more tasks.
          </Text>
          <Pressable
            onPress={() => router.dismissAll()}
            style={({ pressed }) => [
              styles.backButton,
              { transform: [{ scale: pressed ? 0.97 : 1 }] },
            ]}
          >
            <Text style={styles.backButtonText}>Go back</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top + webTopInset }]}>
      <Pressable
        onPress={() => router.dismissAll()}
        style={({ pressed }) => [styles.closeBtn, { opacity: pressed ? 0.6 : 1 }]}
      >
        <Ionicons name="close" size={24} color={Colors.text} />
      </Pressable>

      <View style={styles.content}>
        <View style={styles.labelRow}>
          <Text style={styles.labelText}>YOUR NEXT STEP</Text>
        </View>

        <View style={styles.taskCard}>
          <View style={[styles.goalBadge, { backgroundColor: result.goal.color + "20" }]}>
            <View style={[styles.goalBadgeDot, { backgroundColor: result.goal.color }]} />
            <Text style={[styles.goalBadgeText, { color: result.goal.color }]}>
              {result.goal.title}
            </Text>
          </View>

          <Text style={styles.taskTitle}>{result.task.title}</Text>
          <Text style={styles.reason}>{result.reason}</Text>

          <View style={styles.metaRow}>
            <View style={styles.metaItem}>
              <Ionicons name="time-outline" size={16} color={Colors.textSecondary} />
              <Text style={styles.metaText}>{result.task.estimatedMinutes} min</Text>
            </View>
            <View style={styles.metaItem}>
              <Ionicons
                name={ENERGY_ICONS[result.task.energyRequired] as any}
                size={16}
                color={Colors.textSecondary}
              />
              <Text style={styles.metaText}>
                {result.task.energyRequired.charAt(0).toUpperCase() + result.task.energyRequired.slice(1)} energy
              </Text>
            </View>
            <View style={styles.metaItem}>
              <Ionicons name="flag" size={14} color={PRIORITY_COLORS[result.task.priority]} />
              <Text style={[styles.metaText, { color: PRIORITY_COLORS[result.task.priority] }]}>
                {result.task.priority.charAt(0).toUpperCase() + result.task.priority.slice(1)}
              </Text>
            </View>
          </View>

          {result.task.deadline && (
            <View style={styles.deadlineRow}>
              <Ionicons name="calendar-outline" size={14} color={Colors.textSecondary} />
              <Text style={styles.deadlineText}>
                Due {new Date(result.task.deadline).toLocaleDateString()}
              </Text>
            </View>
          )}
        </View>

        <View style={styles.actions}>
          <Pressable
            onPress={handleComplete}
            style={({ pressed }) => [
              styles.completeButton,
              { transform: [{ scale: pressed ? 0.97 : 1 }] },
            ]}
          >
            <Ionicons name="checkmark" size={22} color="#fff" />
            <Text style={styles.completeText}>Mark Done</Text>
          </Pressable>

          <Pressable
            onPress={handleSkip}
            style={({ pressed }) => [
              styles.skipButton,
              { opacity: pressed ? 0.7 : 1 },
            ]}
          >
            <Text style={styles.skipText}>Not now</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  closeBtn: {
    position: "absolute",
    top: Platform.OS === "web" ? 67 + 16 : 56,
    right: 20,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.surfaceAlt,
    alignItems: "center",
    justifyContent: "center",
    zIndex: 10,
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    justifyContent: "center",
    gap: 24,
  },
  labelRow: {
    alignItems: "center",
  },
  labelText: {
    fontFamily: "Outfit_600SemiBold",
    fontSize: 13,
    color: Colors.primary,
    letterSpacing: 1.5,
  },
  taskCard: {
    backgroundColor: Colors.surface,
    borderRadius: 20,
    padding: 24,
    gap: 16,
    borderWidth: 1,
    borderColor: Colors.borderLight,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 12,
    elevation: 3,
  },
  goalBadge: {
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "flex-start",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    gap: 6,
  },
  goalBadgeDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  goalBadgeText: {
    fontFamily: "Outfit_500Medium",
    fontSize: 13,
  },
  taskTitle: {
    fontFamily: "Outfit_700Bold",
    fontSize: 26,
    color: Colors.text,
    lineHeight: 34,
  },
  reason: {
    fontFamily: "Outfit_400Regular",
    fontSize: 15,
    color: Colors.textSecondary,
    lineHeight: 22,
  },
  metaRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 16,
  },
  metaItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  metaText: {
    fontFamily: "Outfit_400Regular",
    fontSize: 13,
    color: Colors.textSecondary,
  },
  deadlineRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  deadlineText: {
    fontFamily: "Outfit_400Regular",
    fontSize: 13,
    color: Colors.textSecondary,
  },
  actions: {
    gap: 12,
    paddingTop: 8,
  },
  completeButton: {
    backgroundColor: Colors.success,
    borderRadius: 16,
    paddingVertical: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    shadowColor: Colors.success,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 4,
  },
  completeText: {
    fontFamily: "Outfit_600SemiBold",
    fontSize: 17,
    color: "#fff",
  },
  skipButton: {
    alignItems: "center",
    paddingVertical: 12,
  },
  skipText: {
    fontFamily: "Outfit_500Medium",
    fontSize: 15,
    color: Colors.textSecondary,
  },
  emptyContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 32,
    gap: 12,
  },
  emptyTitle: {
    fontFamily: "Outfit_600SemiBold",
    fontSize: 20,
    color: Colors.text,
  },
  emptyText: {
    fontFamily: "Outfit_400Regular",
    fontSize: 15,
    color: Colors.textSecondary,
    textAlign: "center",
    lineHeight: 22,
  },
  backButton: {
    marginTop: 16,
    backgroundColor: Colors.primary,
    borderRadius: 12,
    paddingVertical: 14,
    paddingHorizontal: 32,
  },
  backButtonText: {
    fontFamily: "Outfit_600SemiBold",
    fontSize: 16,
    color: "#fff",
  },
});
