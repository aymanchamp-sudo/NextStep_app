import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  Pressable,
  ScrollView,
  Platform,
} from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";
import { useData } from "@/lib/data-context";
import { EnergyLevel, Priority } from "@/lib/types";

const ENERGY_OPTIONS: { label: string; value: EnergyLevel; icon: string; color: string }[] = [
  { label: "Low", value: "low", icon: "battery-dead", color: Colors.energyLow },
  { label: "Medium", value: "medium", icon: "battery-half", color: Colors.energyMedium },
  { label: "High", value: "high", icon: "battery-full", color: Colors.energyHigh },
];

const PRIORITY_OPTIONS: { label: string; value: Priority; color: string }[] = [
  { label: "Low", value: "low", color: Colors.textTertiary },
  { label: "Medium", value: "medium", color: Colors.primary },
  { label: "High", value: "high", color: Colors.warning },
  { label: "Urgent", value: "urgent", color: Colors.error },
];

const TIME_PRESETS = [5, 10, 15, 30, 45, 60, 90, 120];

export default function AddTaskSheet() {
  const { goalId } = useLocalSearchParams<{ goalId: string }>();
  const { addTask } = useData();
  const [title, setTitle] = useState("");
  const [minutes, setMinutes] = useState(30);
  const [energy, setEnergy] = useState<EnergyLevel>("medium");
  const [priority, setPriority] = useState<Priority>("medium");

  const handleSave = async () => {
    const trimmed = title.trim();
    if (!trimmed || !goalId) return;
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    await addTask(goalId, {
      title: trimmed,
      estimatedMinutes: minutes,
      energyRequired: energy,
      priority,
    });
    router.back();
  };

  const formatTime = (m: number) => {
    if (m < 60) return `${m}m`;
    const h = Math.floor(m / 60);
    const r = m % 60;
    return r > 0 ? `${h}h ${r}m` : `${h}h`;
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.scrollContent}
      keyboardShouldPersistTaps="handled"
    >
      <Text style={styles.title}>New Task</Text>

      <View style={styles.section}>
        <Text style={styles.label}>Task name</Text>
        <TextInput
          style={styles.input}
          placeholder="What needs to be done?"
          placeholderTextColor={Colors.textTertiary}
          value={title}
          onChangeText={setTitle}
          autoFocus
        />
      </View>

      <View style={styles.section}>
        <Text style={styles.label}>Estimated time</Text>
        <View style={styles.chipRow}>
          {TIME_PRESETS.map((t) => (
            <Pressable
              key={t}
              onPress={() => {
                Haptics.selectionAsync();
                setMinutes(t);
              }}
              style={[styles.chip, minutes === t && styles.chipActive]}
            >
              <Text style={[styles.chipText, minutes === t && styles.chipTextActive]}>
                {formatTime(t)}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.label}>Energy required</Text>
        <View style={styles.energyRow}>
          {ENERGY_OPTIONS.map((opt) => (
            <Pressable
              key={opt.value}
              onPress={() => {
                Haptics.selectionAsync();
                setEnergy(opt.value);
              }}
              style={[
                styles.energyCard,
                energy === opt.value && { borderColor: opt.color, backgroundColor: opt.color + "15" },
              ]}
            >
              <Ionicons
                name={opt.icon as any}
                size={20}
                color={energy === opt.value ? opt.color : Colors.textTertiary}
              />
              <Text style={[styles.energyLabel, energy === opt.value && { color: opt.color }]}>
                {opt.label}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.label}>Priority</Text>
        <View style={styles.chipRow}>
          {PRIORITY_OPTIONS.map((opt) => (
            <Pressable
              key={opt.value}
              onPress={() => {
                Haptics.selectionAsync();
                setPriority(opt.value);
              }}
              style={[
                styles.chip,
                priority === opt.value && { borderColor: opt.color, backgroundColor: opt.color + "15" },
              ]}
            >
              <Text
                style={[
                  styles.chipText,
                  priority === opt.value && { color: opt.color },
                ]}
              >
                {opt.label}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      <Pressable
        onPress={handleSave}
        disabled={!title.trim()}
        style={({ pressed }) => [
          styles.saveButton,
          { opacity: !title.trim() ? 0.4 : pressed ? 0.85 : 1 },
          { transform: [{ scale: pressed ? 0.97 : 1 }] },
        ]}
      >
        <Ionicons name="checkmark" size={20} color="#fff" />
        <Text style={styles.saveText}>Add Task</Text>
      </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContent: {
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 40,
    gap: 20,
  },
  title: {
    fontFamily: "Outfit_700Bold",
    fontSize: 24,
    color: Colors.text,
    textAlign: "center",
  },
  section: {
    gap: 8,
  },
  label: {
    fontFamily: "Outfit_500Medium",
    fontSize: 13,
    color: Colors.textSecondary,
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  input: {
    backgroundColor: Colors.surfaceAlt,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    fontFamily: "Outfit_400Regular",
    color: Colors.text,
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  chipRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 18,
    backgroundColor: Colors.surfaceAlt,
    borderWidth: 1.5,
    borderColor: "transparent",
  },
  chipActive: {
    backgroundColor: Colors.primaryLight,
    borderColor: Colors.primary,
  },
  chipText: {
    fontFamily: "Outfit_500Medium",
    fontSize: 14,
    color: Colors.textSecondary,
  },
  chipTextActive: {
    color: Colors.primary,
  },
  energyRow: {
    flexDirection: "row",
    gap: 8,
  },
  energyCard: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 12,
    borderRadius: 14,
    backgroundColor: Colors.surfaceAlt,
    borderWidth: 1.5,
    borderColor: "transparent",
    gap: 4,
  },
  energyLabel: {
    fontFamily: "Outfit_500Medium",
    fontSize: 12,
    color: Colors.textTertiary,
  },
  saveButton: {
    backgroundColor: Colors.primary,
    borderRadius: 14,
    paddingVertical: 15,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    marginTop: 4,
  },
  saveText: {
    fontFamily: "Outfit_600SemiBold",
    fontSize: 16,
    color: "#fff",
  },
});
