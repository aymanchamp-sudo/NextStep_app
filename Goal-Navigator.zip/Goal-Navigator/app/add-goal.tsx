import React, { useState } from "react";
import { StyleSheet, Text, View, TextInput, Pressable } from "react-native";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";
import { useData } from "@/lib/data-context";

export default function AddGoalSheet() {
  const [title, setTitle] = useState("");
  const { addGoal } = useData();

  const handleSave = async () => {
    const trimmed = title.trim();
    if (!trimmed) return;
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    await addGoal(trimmed);
    router.back();
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>New Goal</Text>
      <TextInput
        style={styles.input}
        placeholder="What do you want to achieve?"
        placeholderTextColor={Colors.textTertiary}
        value={title}
        onChangeText={setTitle}
        autoFocus
        returnKeyType="done"
        onSubmitEditing={handleSave}
      />
      <Pressable
        onPress={handleSave}
        disabled={!title.trim()}
        style={({ pressed }) => [
          styles.saveButton,
          { opacity: !title.trim() ? 0.4 : pressed ? 0.85 : 1 },
          { transform: [{ scale: pressed ? 0.97 : 1 }] },
        ]}
      >
        <Ionicons name="checkmark" size={20} color="#fff" />
        <Text style={styles.saveText}>Create Goal</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingHorizontal: 24,
    paddingTop: 24,
    gap: 20,
  },
  title: {
    fontFamily: "Outfit_700Bold",
    fontSize: 24,
    color: Colors.text,
    textAlign: "center",
  },
  input: {
    backgroundColor: Colors.surfaceAlt,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    fontFamily: "Outfit_400Regular",
    color: Colors.text,
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  saveButton: {
    backgroundColor: Colors.primary,
    borderRadius: 14,
    paddingVertical: 15,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },
  saveText: {
    fontFamily: "Outfit_600SemiBold",
    fontSize: 16,
    color: "#fff",
  },
});
