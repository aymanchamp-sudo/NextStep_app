import React, { useMemo } from "react";
import {
  StyleSheet,
  Text,
  View,
  Pressable,
  FlatList,
  Platform,
  Alert,
} from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";
import { useData } from "@/lib/data-context";
import { Task } from "@/lib/types";

const ENERGY_ICONS: Record<string, string> = {
  low: "battery-dead",
  medium: "battery-half",
  high: "battery-full",
};

const PRIORITY_COLORS: Record<string, string> = {
  low: Colors.textTertiary,
  medium: Colors.primary,
  high: Colors.warning,
  urgent: Colors.error,
};

function TaskItem({
  task,
  goalId,
  goalColor,
}: {
  task: Task;
  goalId: string;
  goalColor: string;
}) {
  const { completeTask, deleteTask } = useData();

  const handleToggle = async () => {
    if (task.completed) return;
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    await completeTask(goalId, task.id);
  };

  const handleDelete = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    Alert.alert("Delete Task", `Delete "${task.title}"?`, [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: () => deleteTask(goalId, task.id),
      },
    ]);
  };

  return (
    <View style={[styles.taskItem, task.completed && styles.taskCompleted]}>
      <Pressable onPress={handleToggle} style={styles.checkArea}>
        <View
          style={[
            styles.checkbox,
            task.completed && { backgroundColor: goalColor, borderColor: goalColor },
          ]}
        >
          {task.completed && <Ionicons name="checkmark" size={14} color="#fff" />}
        </View>
      </Pressable>

      <View style={styles.taskContent}>
        <Text
          style={[styles.taskTitle, task.completed && styles.taskTitleDone]}
          numberOfLines={2}
        >
          {task.title}
        </Text>
        <View style={styles.taskMeta}>
          <View style={styles.metaChip}>
            <Ionicons name="time-outline" size={12} color={Colors.textTertiary} />
            <Text style={styles.metaText}>{task.estimatedMinutes}m</Text>
          </View>
          <View style={styles.metaChip}>
            <Ionicons
              name={ENERGY_ICONS[task.energyRequired] as any}
              size={12}
              color={Colors.textTertiary}
            />
            <Text style={styles.metaText}>{task.energyRequired}</Text>
          </View>
          <View style={[styles.priorityDot, { backgroundColor: PRIORITY_COLORS[task.priority] }]} />
        </View>
      </View>

      <Pressable
        onPress={handleDelete}
        style={({ pressed }) => [styles.deleteBtn, { opacity: pressed ? 0.5 : 1 }]}
      >
        <Ionicons name="trash-outline" size={18} color={Colors.textTertiary} />
      </Pressable>
    </View>
  );
}

export default function GoalDetailScreen() {
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { goals } = useData();
  const webTopInset = Platform.OS === "web" ? 67 : 0;

  const goal = useMemo(() => goals.find((g) => g.id === id), [goals, id]);

  if (!goal) {
    return (
      <View style={[styles.container, { paddingTop: insets.top + webTopInset }]}>
        <Text style={styles.emptyTitle}>Goal not found</Text>
      </View>
    );
  }

  const pendingTasks = goal.tasks.filter((t) => !t.completed);
  const completedTasks = goal.tasks.filter((t) => t.completed);
  const allTasks = [...pendingTasks, ...completedTasks];

  const handleAddTask = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push({ pathname: "/add-task", params: { goalId: goal.id } });
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top + webTopInset }]}>
      <View style={styles.header}>
        <Pressable
          onPress={() => router.back()}
          style={({ pressed }) => [styles.backBtn, { opacity: pressed ? 0.6 : 1 }]}
        >
          <Ionicons name="chevron-back" size={22} color={Colors.text} />
        </Pressable>
        <View style={styles.headerCenter}>
          <View style={[styles.headerDot, { backgroundColor: goal.color }]} />
          <Text style={styles.headerTitle} numberOfLines={1}>
            {goal.title}
          </Text>
        </View>
        <Pressable
          onPress={handleAddTask}
          style={({ pressed }) => [styles.addBtn, { opacity: pressed ? 0.6 : 1 }]}
        >
          <Ionicons name="add" size={24} color={Colors.primary} />
        </Pressable>
      </View>

      <View style={styles.progressSection}>
        <View style={styles.progressInfo}>
          <Text style={styles.progressText}>
            {completedTasks.length} of {goal.tasks.length} completed
          </Text>
          <Text style={[styles.progressPercent, { color: goal.color }]}>
            {goal.tasks.length > 0
              ? Math.round((completedTasks.length / goal.tasks.length) * 100)
              : 0}
            %
          </Text>
        </View>
        <View style={styles.progressTrack}>
          <View
            style={[
              styles.progressFill,
              {
                width: `${goal.tasks.length > 0 ? (completedTasks.length / goal.tasks.length) * 100 : 0}%`,
                backgroundColor: goal.color,
              },
            ]}
          />
        </View>
      </View>

      <FlatList
        data={allTasks}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TaskItem task={item} goalId={goal.id} goalColor={goal.color} />
        )}
        contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 24 }]}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Ionicons name="list-outline" size={40} color={Colors.textTertiary} />
            <Text style={styles.emptyTitle}>No tasks yet</Text>
            <Text style={styles.emptyText}>
              Tap + to add your first task
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 8,
  },
  backBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.surfaceAlt,
    alignItems: "center",
    justifyContent: "center",
  },
  headerCenter: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  headerDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  headerTitle: {
    fontFamily: "Outfit_600SemiBold",
    fontSize: 20,
    color: Colors.text,
    flex: 1,
  },
  addBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.primaryLight,
    alignItems: "center",
    justifyContent: "center",
  },
  progressSection: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    gap: 8,
  },
  progressInfo: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  progressText: {
    fontFamily: "Outfit_400Regular",
    fontSize: 13,
    color: Colors.textSecondary,
  },
  progressPercent: {
    fontFamily: "Outfit_600SemiBold",
    fontSize: 14,
  },
  progressTrack: {
    height: 6,
    backgroundColor: Colors.surfaceAlt,
    borderRadius: 3,
    overflow: "hidden",
  },
  progressFill: {
    height: "100%",
    borderRadius: 3,
  },
  list: {
    paddingHorizontal: 24,
    paddingTop: 8,
    gap: 8,
  },
  taskItem: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.surface,
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: Colors.borderLight,
    gap: 12,
  },
  taskCompleted: {
    opacity: 0.6,
  },
  checkArea: {
    padding: 2,
  },
  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: Colors.border,
    alignItems: "center",
    justifyContent: "center",
  },
  taskContent: {
    flex: 1,
    gap: 4,
  },
  taskTitle: {
    fontFamily: "Outfit_500Medium",
    fontSize: 15,
    color: Colors.text,
  },
  taskTitleDone: {
    textDecorationLine: "line-through",
    color: Colors.textTertiary,
  },
  taskMeta: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  metaChip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 3,
  },
  metaText: {
    fontFamily: "Outfit_400Regular",
    fontSize: 11,
    color: Colors.textTertiary,
  },
  priorityDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  deleteBtn: {
    padding: 4,
  },
  emptyState: {
    alignItems: "center",
    justifyContent: "center",
    paddingTop: 60,
    gap: 10,
  },
  emptyTitle: {
    fontFamily: "Outfit_600SemiBold",
    fontSize: 17,
    color: Colors.text,
  },
  emptyText: {
    fontFamily: "Outfit_400Regular",
    fontSize: 14,
    color: Colors.textSecondary,
  },
});
