import React, { createContext, useContext, useState, useEffect, useCallback, useMemo, ReactNode } from "react";
import * as Crypto from "expo-crypto";
import { Goal, Task, EnergyLevel, Priority } from "./types";
import { loadGoals, saveGoals } from "./storage";

const GOAL_COLORS = ["#0F7B6C", "#3B82F6", "#8B5CF6", "#EC4899", "#F59E0B", "#EF4444", "#10B981", "#6366F1"];

interface DataContextValue {
  goals: Goal[];
  isLoading: boolean;
  addGoal: (title: string) => Promise<Goal>;
  updateGoal: (id: string, title: string) => Promise<void>;
  deleteGoal: (id: string) => Promise<void>;
  addTask: (goalId: string, task: Omit<Task, "id" | "goalId" | "completed" | "createdAt">) => Promise<void>;
  updateTask: (goalId: string, taskId: string, updates: Partial<Task>) => Promise<void>;
  deleteTask: (goalId: string, taskId: string) => Promise<void>;
  completeTask: (goalId: string, taskId: string) => Promise<void>;
}

const DataContext = createContext<DataContextValue | null>(null);

export function DataProvider({ children }: { children: ReactNode }) {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadGoals().then((g) => {
      setGoals(g);
      setIsLoading(false);
    });
  }, []);

  const persist = useCallback(async (updated: Goal[]) => {
    setGoals(updated);
    await saveGoals(updated);
  }, []);

  const addGoal = useCallback(async (title: string): Promise<Goal> => {
    const newGoal: Goal = {
      id: Crypto.randomUUID(),
      title,
      color: GOAL_COLORS[Math.floor(Math.random() * GOAL_COLORS.length)],
      tasks: [],
      createdAt: new Date().toISOString(),
    };
    const updated = [...goals, newGoal];
    await persist(updated);
    return newGoal;
  }, [goals, persist]);

  const updateGoal = useCallback(async (id: string, title: string) => {
    const updated = goals.map((g) => (g.id === id ? { ...g, title } : g));
    await persist(updated);
  }, [goals, persist]);

  const deleteGoal = useCallback(async (id: string) => {
    const updated = goals.filter((g) => g.id !== id);
    await persist(updated);
  }, [goals, persist]);

  const addTask = useCallback(async (goalId: string, task: Omit<Task, "id" | "goalId" | "completed" | "createdAt">) => {
    const newTask: Task = {
      ...task,
      id: Crypto.randomUUID(),
      goalId,
      completed: false,
      createdAt: new Date().toISOString(),
    };
    const updated = goals.map((g) =>
      g.id === goalId ? { ...g, tasks: [...g.tasks, newTask] } : g
    );
    await persist(updated);
  }, [goals, persist]);

  const updateTask = useCallback(async (goalId: string, taskId: string, updates: Partial<Task>) => {
    const updated = goals.map((g) =>
      g.id === goalId
        ? { ...g, tasks: g.tasks.map((t) => (t.id === taskId ? { ...t, ...updates } : t)) }
        : g
    );
    await persist(updated);
  }, [goals, persist]);

  const deleteTask = useCallback(async (goalId: string, taskId: string) => {
    const updated = goals.map((g) =>
      g.id === goalId ? { ...g, tasks: g.tasks.filter((t) => t.id !== taskId) } : g
    );
    await persist(updated);
  }, [goals, persist]);

  const completeTask = useCallback(async (goalId: string, taskId: string) => {
    const updated = goals.map((g) =>
      g.id === goalId
        ? { ...g, tasks: g.tasks.map((t) => (t.id === taskId ? { ...t, completed: true } : t)) }
        : g
    );
    await persist(updated);
  }, [goals, persist]);

  const value = useMemo(
    () => ({ goals, isLoading, addGoal, updateGoal, deleteGoal, addTask, updateTask, deleteTask, completeTask }),
    [goals, isLoading, addGoal, updateGoal, deleteGoal, addTask, updateTask, deleteTask, completeTask]
  );

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
}

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error("useData must be used within DataProvider");
  return ctx;
}
