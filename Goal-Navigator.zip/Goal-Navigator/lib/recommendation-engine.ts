import { Goal, Task, UserInput, Recommendation, EnergyLevel, Priority } from "./types";

const ENERGY_RANK: Record<EnergyLevel, number> = {
  low: 1,
  medium: 2,
  high: 3,
};

const PRIORITY_SCORE: Record<Priority, number> = {
  low: 1,
  medium: 2,
  high: 3,
  urgent: 5,
};

function energyFits(required: EnergyLevel, available: EnergyLevel): boolean {
  return ENERGY_RANK[required] <= ENERGY_RANK[available];
}

function deadlineUrgency(task: Task): number {
  if (!task.deadline) return 0;
  const now = Date.now();
  const deadline = new Date(task.deadline).getTime();
  const hoursLeft = (deadline - now) / (1000 * 60 * 60);
  if (hoursLeft < 0) return 10;
  if (hoursLeft < 24) return 8;
  if (hoursLeft < 72) return 5;
  if (hoursLeft < 168) return 2;
  return 0;
}

function scoreTask(task: Task): number {
  let score = 0;
  score += PRIORITY_SCORE[task.priority] * 10;
  score += deadlineUrgency(task) * 5;
  score += (1 / Math.max(task.estimatedMinutes, 1)) * 3;
  return score;
}

function generateReason(task: Task, goal: Goal): string {
  if (task.deadline) {
    const hoursLeft = (new Date(task.deadline).getTime() - Date.now()) / (1000 * 60 * 60);
    if (hoursLeft < 0) return `This is overdue and needs attention for "${goal.title}"`;
    if (hoursLeft < 24) return `Due very soon — important for "${goal.title}"`;
    if (hoursLeft < 72) return `Coming up within a few days for "${goal.title}"`;
  }
  if (task.priority === "urgent") return `Urgent priority task for "${goal.title}"`;
  if (task.priority === "high") return `High priority — moves "${goal.title}" forward`;
  if (task.estimatedMinutes <= 15) return `Quick win that progresses "${goal.title}"`;
  return `Best match for your current time and energy toward "${goal.title}"`;
}

export function recommend(goals: Goal[], input: UserInput): Recommendation | null {
  const candidates: { task: Task; goal: Goal; score: number }[] = [];

  for (const goal of goals) {
    for (const task of goal.tasks) {
      if (task.completed) continue;
      if (task.estimatedMinutes > input.availableMinutes) continue;
      if (!energyFits(task.energyRequired, input.energyLevel)) continue;
      candidates.push({ task, goal, score: scoreTask(task) });
    }
  }

  if (candidates.length === 0) return null;

  candidates.sort((a, b) => b.score - a.score);
  const best = candidates[0];
  return {
    task: best.task,
    goal: best.goal,
    reason: generateReason(best.task, best.goal),
  };
}
