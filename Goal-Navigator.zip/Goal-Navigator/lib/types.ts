export type EnergyLevel = "low" | "medium" | "high";

export type Priority = "low" | "medium" | "high" | "urgent";

export interface Task {
  id: string;
  goalId: string;
  title: string;
  estimatedMinutes: number;
  energyRequired: EnergyLevel;
  priority: Priority;
  deadline?: string;
  completed: boolean;
  createdAt: string;
}

export interface Goal {
  id: string;
  title: string;
  color: string;
  tasks: Task[];
  createdAt: string;
}

export interface UserInput {
  availableMinutes: number;
  energyLevel: EnergyLevel;
}

export interface Recommendation {
  task: Task;
  goal: Goal;
  reason: string;
}
