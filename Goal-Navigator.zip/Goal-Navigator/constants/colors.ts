const Colors = {
  primary: "#0F7B6C",
  primaryLight: "#E8F5F2",
  primaryDark: "#0A5C51",
  accent: "#FF6B35",
  accentLight: "#FFF0E8",
  background: "#FAFBFC",
  surface: "#FFFFFF",
  surfaceAlt: "#F3F5F7",
  text: "#1A1D21",
  textSecondary: "#6B7280",
  textTertiary: "#9CA3AF",
  border: "#E5E7EB",
  borderLight: "#F0F1F3",
  success: "#10B981",
  warning: "#F59E0B",
  error: "#EF4444",
  energyLow: "#60A5FA",
  energyMedium: "#FBBF24",
  energyHigh: "#F87171",

  light: {
    text: "#1A1D21",
    background: "#FAFBFC",
    tint: "#0F7B6C",
    tabIconDefault: "#9CA3AF",
    tabIconSelected: "#0F7B6C",
  },
};

export default Colors;
